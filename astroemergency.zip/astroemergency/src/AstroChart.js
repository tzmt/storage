import React, {Component} from 'react';



export default class AstroChart extends Component {
    constructor() {
        super();
        this.state = {stuff: null};
    }


    render() {
        return (
          <div />  
        );
    }
}
